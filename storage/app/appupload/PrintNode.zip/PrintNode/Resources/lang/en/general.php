<?php

return [

    'name'              => 'PrintNode',
    'description'       => 'This is my awesome module',

];