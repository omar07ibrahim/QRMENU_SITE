<?php

return [

    'name'              => 'Themeswitcher',
    'description'       => 'This is my awesome module',

];