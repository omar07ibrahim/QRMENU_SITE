<?php

return [

    'name'              => 'Poscloud',
    'description'       => 'This is my awesome module',

];